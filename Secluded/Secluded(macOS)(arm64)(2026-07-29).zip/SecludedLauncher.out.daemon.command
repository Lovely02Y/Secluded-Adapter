#!/bin/bash

cd "$(dirname "$0")"

export DYLD_LIBRARY_PATH=.

while true; do
    chmod +x SecludedLauncher.out.command 2>/dev/null
    
    ./SecludedLauncher.out.command
    
    code=$?

    if [ "$code" -ne 0 ]; then
        echo "code == $code"
        sleep 1
        continue
    fi
    
    break
done
