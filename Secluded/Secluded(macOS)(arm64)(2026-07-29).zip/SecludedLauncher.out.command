#!/bin/bash

cd "$(dirname "$0")"

export DYLD_LIBRARY_PATH=.

while true; do
    chmod +x SecludedLauncher.out engine.out 2>/dev/null

    ./SecludedLauncher.out --console
    
    code=$?

    if [[ "$code" -eq 0 && -d "upgrade" ]]; then
        cp -rf upgrade/* ./ 
        rm -rf upgrade
        continue
    fi

    chmod +x SecludedLauncher.out engine.out 2>/dev/null
    
    if [[ "$code" -eq 0 ]]; then
        if [ -f "engine.out" ]; then
            ./engine.out --console
        fi
    fi

    break
done
